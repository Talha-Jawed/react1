
var emailRef = document.getElementById('email');
var passwordRef = document.getElementById('password');
var usernameRef = document.getElementById('username');
var phoneRef = document.getElementById('phone');
var errorRef = document.getElementById('error');
var emailRegex = /^\w+([\.-]?\w+)*@\w+([\.-]?\w+)*(\.\w{2,3})+$/;


function emailValidate() {
    var emails = document.getElementById('email')
    var emailVal = emails.value;
    var re = /^(([^<>()[\]\\.,;:\s@\"]+(\.[^<>()[\]\\.,;:\s@\"]+)*)|(\".+\"))@((\[[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\])|(([a-zA-Z\-0-9]+\.)+[a-zA-Z]{2,}))$/;
    if (emailVal === ' ') {
        var err = document.getElementById('errEmail');
        err.style.fontSize = '0.8em'
        err.innerHTML = '*please don`t left spaces'
        err.style.color = 'red'
    }
    else if (!re.test(emailVal) && emailVal.length >= 1) {
        var err = document.getElementById('errEmail');
        err.style.fontSize = '0.8em'
        err.innerHTML = '*Enter email correctly'
        err.style.color = 'red'
    }
    else {
        document.getElementById('errEmail').innerHTML = ''
    }
    btnValidate()

}

var submitAnAd = document.getElementById('submitAnAd')

function userAuth(){
    if(currentUserUID !== null){
        submitAnAd.disabled = false
        submitAnAd.style.opacity = '1'
    }else{
        submitAnAd.disabled = true
        submitAnAd.style.opacity = '0.7'
    }
}

function passValidate() {
    var pass = document.getElementById('password')
    var res = ("^(?=.*[a-z])(?=.*[A-Z])(?=.*[0-9])(?=.*[!@#\$%\^&\*])(?=.{8,})");
    var passVal = pass.value;
    if (passVal.indexOf(' ') !== -1) {
        var err = document.getElementById('errPass');
        err.style.fontSize = '0.8em'
        err.innerHTML = '*please don`t left spaces'
        err.style.color = 'red'
    }
    else if (!passVal.match(res)) {
        var err = document.getElementById('errPass');
        err.style.fontSize = '0.8em'
        err.innerHTML = 'upper and lowercas and special characters'
        err.style.color = 'red'
    }

    else {
        document.getElementById('errPass').innerHTML = ''
    }
    btnValidate()

}
function nameValidate() {
    var name = document.getElementById('username');
    var nameVal = name.value;
    var reg = new RegExp('^[0-9]+$');
    if (nameVal.indexOf('  ') !== -1) {
        var err = document.getElementById('errName');
        err.style.fontSize = '0.8em'
        err.innerHTML = '*please don`t left spaces'
        err.style.color = 'red'
    }
    else if (nameVal.length <= 4 && nameVal.length >= 1) {
        var err = document.getElementById('errName');
        err.style.fontSize = '0.8em'
        err.innerHTML = '*Name should be greater than 4 characters'
        err.style.color = 'red'
    }
    else if (reg.test(nameVal)) {
        var err = document.getElementById('errName');
        err.style.fontSize = '0.8em'
        err.innerHTML = '*Donot use numbers'
        err.style.color = 'red'
    }
    else {
        document.getElementById('errName').innerHTML = ''
    }
    btnValidate()

}


function btnValidate() {
    var err1 = document.getElementById('err')
    var err2 = document.getElementById('userErr')
    var err3 = document.getElementById('passwordErr')
    var err4 = document.getElementById('emailErr')
    // if (nameRef.value === '' || usernameRef.value === '' || emailRef.value === '' ||
    //     passwordRef.value === '' && err1.innerHTML !== '' || err2.innerHTML !== '' ||
    //     err3.innerHTML !== 'Password Strength : Strong' || err4.innerHTML !== '') {
    //     var signUpBtn = document.getElementById('signUpBtn');
    //     signUpBtn.disabled = true
    //     signUpBtn.style.opacity = '0.5'
    //     signUpBtn.style.cursor = 'text'
    // } else {
    //     var signUpBtn = document.getElementById('signUpBtn');
    //     signUpBtn.disabled = false
    //     signUpBtn.style.opacity = '1'
    //     signUpBtn.style.cursor = 'pointer'
    // }

}

function signup() {
    // console.log('signup invoke', emailRef.value, passwordRef.value, usernameRef.value, phoneRef.value);
    firebase.auth().createUserWithEmailAndPassword(emailRef.value, passwordRef.value)
        .then((success) => {
            swal("Successfull", "", "success");
            console.log('signup successfully', success);
            location = './login.html';
        })
        .catch((error) => {
            swal("Something went wrong", " ", "error");
            console.error('something went wrong', error);
            errorRef.innerHTML = error.message;

        })
}



function login() {
    console.log('login invoke', emailRef.value, passwordRef.value);
    firebase.auth().signInWithEmailAndPassword(emailRef.value, passwordRef.value)
        .then((success) => {
            swal("Successfull", "", "success");
            console.log('signin successfully', success.user);
            localStorage.setItem('currentUserUid', success.user.uid)
            location = './index.html';
        })
        .catch((error) => {
            swal("Something went wrong", "", "error");
            console.log('something went wrong', error)
        })
}
function logInn() {
    location = './login.html'
}

function logOut() {
    console.log('log out ho rha hai');
    firebase.auth().signOut()
        .then(function () {
            localStorage.clear()
            swal({
                position: 'center',
                type: 'success',
                title: 'You are successfully logout',
                showConfirmButton: false,
                timer: 1500
            })
            setTimeout(() => {
                location = './index.html'
            }, 1500)
        })

}


function upload() {
    console.log('ok')
    location = './submit.html'
}
var fetch = document.getElementById('fech')
var imageUrl;
function previewFile() {
    var file = document.querySelector('input[type=file]').files[0];
    console.log(file, 'file')
    var read = new FileReader();
    console.log(read, 'reader')

    read.addEventListener("load", function () {
        imageUrl = read.result;
        console.log(imageUrl, "image url")
        document.getElementById('file').innerHTML = "File uploaded"
    }, false)
    if (file) {
        var fileReader = read.readAsDataURL(file);
    }
}

function savetoDB() {

    var select = document.getElementById('catag')
    var name = document.getElementById('pName')
    var price = document.getElementById('price')
    var phone = document.getElementById('phone')
    var modl = document.getElementById('model')
    var file = document.getElementById('file')
    // var dscption = document.getElementById('Discription'),value


    var data = {
        select: select.value,
        name: name.value,
        price: price.value,
        phone: phone.value,
        model: modl.value,
        file: imageUrl
        // Discription: dscption.value
    }
    console.log(data.file, 'picture')

    console.log(data, 'donne')
    // location = './home.html'
    //console.log(select.value, 'done')
    // console.log(name,price, 'adds')
    var currentUserUID = localStorage.getItem('currentUserUid')
    if (data.name !== '' & data.price !== '' & data.phone !== '' & data.file !== '') {
        console.log('fire')
        firebase.database().ref('/' + currentUserUID  + '/').push(data)
            .then(() => {
                swal({
                    position: 'center',
                    type: 'success',
                    title: 'Submit successful',
                    showConfirmButton: false,
                    timer: 1500
                })
                setTimeout(() => {
                    location = './index.html'
                }, 1500)

                console.log('succcess')
                location = './index.html'
            })
    }
    else {
        swal("Something went wrong", " ", "error");
        console.error('plese fill ')
    }


}

function out() {
    firebase.database().ref('/').on('value', (snaps) => {
        // console.log(snaps.val())
        for (var key in snaps.val()) {
            for (var key2 in snaps.val()[key]) {
                var value = snaps.val()[key][key2]
                // console.log(value)
                // console.log(key2)
                // firebase.database().ref('/').on('child_added', (snapshot) => {
                //     var snapVal = snapshot.val();
                //     console.log(snapVal);
                //     var objVal = Object.values(snapVal);
                //     for (i = 0; i < objVal.length; i++) {
                //         var objVal = Object.values(snapVal);
                //         var objValProp = objVal[i]
                //         console.log(objValProp);
                //         // console.log(objValProp.file)
                var cardDivs = document.createElement('div');
                cardDivs.setAttribute('id', 'fetchImage');
                cardDivs.setAttribute('class', 'card');
                cardDivs.setAttribute('class', 'col-md-3');
                var imgBoxs = document.createElement('img');
                imgBoxs.setAttribute('id', 'imgBox');
                // imgBoxs.style.width = '200px';
                // imgBoxs.style.width = '200px';
                imgBoxs.setAttribute('class', 'card-img-top');
                // imgBoxs.setAttribute('onClick', 'image()')
                imgBoxs.src = value.file;
                var titleDivs = document.createElement('div');
                titleDivs.setAttribute('id', 'titleDiv');
                titleDivs.setAttribute('id', key2);
                titleDivs.setAttribute('class', 'card-img-top');
                var headTitle = document.createElement('h4');
                headTitle.setAttribute('id', 'head5');
                headTitle.innerHTML = value.name;
                var paraModels = document.createElement('p')
                paraModels.setAttribute('id', 'paraModel');
                var prizeSpan = document.createElement('span');
                prizeSpan.innerHTML = 'Rs:' + value.price;
                // paraModels.innerHTML = objValProp.model;
                var myDiv = document.createElement('p');
                var btn = document.createElement('button');
                myDiv.setAttribute('onClick', 'detail(this)');
                myDiv.setAttribute('id', key2);
                var btnTxt = document.createTextNode('Detail!');
                btn.setAttribute('class', 'button');
                btn.appendChild(btnTxt);



                cardDivs.appendChild(imgBoxs);
                cardDivs.appendChild(titleDivs);
                titleDivs.appendChild(headTitle);
                paraModels.appendChild(prizeSpan);
                titleDivs.appendChild(paraModels);
                cardDivs.appendChild(titleDivs);
                fetch.appendChild(cardDivs);
                titleDivs.appendChild(myDiv);
                myDiv.appendChild(btn);


            }
            // console.log(objVal[0])
        }
    })



    var userId = localStorage.getItem('currentUserUid')

    // // console.log(userId)
    if (userId === null) {
        document.getElementById('LogIn').style.display = 'inline-block'
        document.getElementById('logOut').style.display = 'none'
    } else {
        document.getElementById('LogIn').style.display = 'none'
        document.getElementById('logOut').style.display = 'inline-block'
    }
}
// var select = document.getElementById('catag')
// var price = document.getElementById('price')
// var phone = document.getElementById('phone')
// var name = document.getElementById('pName')
// var modl = document.getElementById('model')
// var file = document.getElementById('file')
// // var dscption = document.getElementById('Discription'),value


// var data = {
//     select: select.value,
//     name: name.value,
//     // price: price.value,
//     // phone: phone.value,
//     // model: modl.value,
//     file: imageUrl
//     // Discription: dscption.value
// }

// function search() {
//     var search = document.getElementById('search').value
// }

var currentUserUID = localStorage.getItem('currentUserUid')
var AdCate = document.getElementById('catag')
var adTitle = document.getElementById('search')
var div = document.getElementById('fech')

// console.log(div)
function search() {
   var category = AdCate.value
    // console.log(category)
    div.innerHTML = "",
    firebase.database().ref('/').on('child_added', (snapShot) => {

        // console.log(snaps.val())
        for (var key in snapShot.val()) {
            var value = snapShot.val()[key];
                    // console.log(value)
    
      if (value.select === category) {

        // console.log(value)
          
      
  
   
    
    

    
        var cardDivs = document.createElement('div');
        cardDivs.setAttribute('id', 'fetchImage');
        cardDivs.setAttribute('class', 'card');
        cardDivs.setAttribute('class', 'col-md-3');
        var imgBoxs = document.createElement('img');
        imgBoxs.setAttribute('id', 'imgBox');
        // imgBoxs.style.width = '200px';
        // imgBoxs.style.width = '200px';
        imgBoxs.setAttribute('class', 'card-img-top');
        // imgBoxs.setAttribute('onClick', 'image()')
        imgBoxs.src = value.file;
        var titleDivs = document.createElement('div');
        titleDivs.setAttribute('id', 'titleDiv');
        // titleDivs.setAttribute('id', key2);
        titleDivs.setAttribute('class', 'card-img-top');
        var headTitle = document.createElement('h4');
        headTitle.setAttribute('id', 'head5');
        headTitle.innerHTML = value.name;
        var paraModels = document.createElement('p')
        paraModels.setAttribute('id', 'paraModel');
        var prizeSpan = document.createElement('span');
        prizeSpan.innerHTML = 'Rs:' + value.price;
        // paraModels.innerHTML = objValProp.model;
        var myDiv = document.createElement('p');
        var btn = document.createElement('button');
        myDiv.setAttribute('onClick', 'detail(this)');
        // myDiv.setAttribute('id', key2);
        var btnTxt = document.createTextNode('Detail!');
        btn.setAttribute('class', 'button');
        btn.appendChild(btnTxt);



        cardDivs.appendChild(imgBoxs);
        cardDivs.appendChild(titleDivs);
        titleDivs.appendChild(headTitle);
        paraModels.appendChild(prizeSpan);
        titleDivs.appendChild(paraModels);
        cardDivs.appendChild(titleDivs);
        fetch.appendChild(cardDivs);
        titleDivs.appendChild(myDiv);
        myDiv.appendChild(btn);

                    
      }
                
      
        }
                })
            }



// function image() {
//     console.log('hfjdjy');

// }


// function detail() {
//     console.log('click ho rha hai');
//     var add_wishlist = true
//     if (localUserId  !== null) {
//         firebase.database().ref('/' + localUserId  + '/wishlist/' + favorite.parentNode.id).push(add_wishlist)
//             .then(() => {
//                 swal({
//                     position: 'center',
//                     type: 'success',
//                     title: 'Added to your wishlist',
//                     showConfirmButton: false,
//                     timer: 2000
//                 })
//             })
//     }
//     else {
//         firebase.database().ref('/user/' + favorite.parentNode.id).push(add_wishlist)
//             .then(() => {
//                 swal({
//                     position: 'center',
//                     type: 'success',
//                     title: 'Added to your wishlist',
//                     showConfirmButton: false,
//                     timer: 2000
//                 })
//             })
//     }

// }
var detailId;
function detail(butn){
    // console.log('detail');
    detailId = butn.parentElement.id;
    console.log(butn.parentElement.id);
    localStorage.setItem('detailkey', detailId );
    
    location = './detail.html';

}


var detailIdForDom = localStorage.getItem('detailkey');
function detaill() {
    
    firebase.database().ref('/').on('child_added', (snapShot) => {

        // console.log(snaps.val())
        for (var key in snapShot.val()) {
            var value = snapShot.val()[key];
                    // console.log(key)
           

                if (key === detailIdForDom) {
                    // console.log(detailIdForDom)
                    console.log(value)
                    

                   
                    var cardDivs = document.createElement('div');
                cardDivs.setAttribute('id', 'fetchImage');
                cardDivs.setAttribute('class', 'card');
                cardDivs.setAttribute('class', 'col-md-3');
                var imgBoxs = document.createElement('img');
                imgBoxs.setAttribute('id', 'imgBox');
                // imgBoxs.style.width = '200px';
                // imgBoxs.style.width = '200px';
                imgBoxs.setAttribute('class', 'card-img-top');
                // imgBoxs.setAttribute('onClick', 'image()')
                imgBoxs.src = value.file;
                var titleDivs = document.createElement('div');
                titleDivs.setAttribute('id', 'titleDiv');
                // titleDivs.setAttribute('id', key2);
                titleDivs.setAttribute('class', 'card-img-top');
                var headTitle = document.createElement('h4');
                headTitle.setAttribute('id', 'head5');
                headTitle.innerHTML = value.name;
                var paraModels = document.createElement('p')
                paraModels.setAttribute('id', 'paraModel');
                var prizeSpan = document.createElement('span');
                prizeSpan.innerHTML = 'Rs:' + value.price;
                // paraModels.innerHTML = objValProp.model;
                var myDiv = document.createElement('p');
                var btn = document.createElement('button');
                myDiv.setAttribute('onClick', 'detail(this)');
                // myDiv.setAttribute('id', key2);
                var btnTxt = document.createTextNode('Detail!');
                btn.setAttribute('class', 'button');
                btn.appendChild(btnTxt);



                cardDivs.appendChild(imgBoxs);
                cardDivs.appendChild(titleDivs);
                titleDivs.appendChild(headTitle);
                paraModels.appendChild(prizeSpan);
                titleDivs.appendChild(paraModels);
                cardDivs.appendChild(titleDivs);
                fetch.appendChild(cardDivs);
                titleDivs.appendChild(myDiv);
                myDiv.appendChild(btn);

                    
            
            }

}
    })
}


// const messaging = firebase.messaging();
// messaging.requestPermission()
// .then(function() {
//     console.log('Notification permission granted.');
//     return messaging.getToken()
// })
// .then(function(token){
//     console.log(token);
// })
// .catch(function(err) {
//     console.log('Unable to get permission to notify.', err);
// });