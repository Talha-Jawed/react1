// Search Category Vice Work Start From Here

var fetchDiv = document.getElementById('fetchingDiv');
var searchFetchiDiv = document.getElementById('searchFetchiDiv');
// fetchDiv.style.display = "block";
// searchFetchiDiv.style.display = "none";
var selectCategoryRef = document.getElementById('Category-page-search');
function searchCategory() {
    var selectCategoryRefVal = selectCategoryRef.options[selectCategoryRef.selectedIndex].text
    console.log(selectCategoryRefVal);
    if (selectCategoryRefVal === 'Select Category') {
        swal({
            type: 'error',
            title: 'Oops...',
            text: "You're Not Selected Any Option...",
        })
        // fetchDiv.style.display = "block";
        // searchFetchiDiv.style.display = "none";
        // alert('not done')
    }
    else {
        // fetchDiv.style.display = "none";
        // searchFetchiDiv.style.display = "block";
        localStorage.setItem('selectedCategory', selectCategoryRefVal);
        if (selectCategoryRefVal === 'Mobile') {
            window.location = '../pages/mobile.html';
            fetchData();

        } else if (selectCategoryRefVal === 'Electronics And Home Appliances') {
            window.location = '../pages/electronic.html';
            fetchData();
        } else if (selectCategoryRefVal === 'Vehicles') {
            window.location = '../pages/vehicle.html';
            fetchData();

        } else if (selectCategoryRefVal === 'Bike') {
            window.location = '../pages/bike.html';
            fetchData();

        } else if (selectCategoryRefVal === 'Property For Sale') {
            window.location = '../pages/sale-property.html';
            fetchData();

        } else if (selectCategoryRefVal === 'Property For Rent') {
            window.location = '../pages/rent-property.html';
            fetchData();

        } else if (selectCategoryRefVal === 'Jobs') {
            window.location = '../pages/job.html';
            fetchData();

        } else if (selectCategoryRefVal === 'Services') {
            window.location = '../pages/service.html';
            fetchData();

        } else if (selectCategoryRefVal === 'Business Industrial & Agriculture') {
            window.location = '../pages/business.html';
            fetchData();

        } else if (selectCategoryRefVal === 'Furniture & Home Decor') {
            window.location = '../pages/furniture.html';
            fetchData();

        } else if (selectCategoryRefVal === 'Animals') {
            window.location = '../pages/animal.html';
            fetchData();

        } else if (selectCategoryRefVal === 'Books, Sports & Hobbies') {
            window.location = '../pages/book.html';
            fetchData();

        } else if (selectCategoryRefVal === 'Fashion & Beauty') {
            window.location = '../pages/fashion.html';
            fetchData();

        } else if (selectCategoryRefVal === 'Kids') {
            window.location = '../pages/kids.html';
            fetchData();

        }
    }
}


function fetchData() {
    var selectCategoryRefVal = localStorage.getItem('selectedCategory');
    console.log(selectCategoryRefVal)
    swal({
        title: "Loading....!",
        text: "Please wait a moment, data searching....",
        timer: 4000,
        showConfirmButton: false
    });
    // db.ref('/Ads/').on('value', (snapCatogary) => {
    //     var snapcategoryName = snapCatogary.val();
    //     console.log(snapcategoryName)
    //     var categoryArr = Object.keys(snapcategoryName)
    //     var matchedFlag = false;
    // })
    db.ref('/Ads/' + selectCategoryRefVal + '/').on('child_added', (snapshot) => {
        // console.log(snapshot.key)
        // console.log(snapshot, 'fetchData')
        var snap = snapshot;
        var keyName = snap.key;
        // console.log(keyName);
        var snapVals = snapshot.val();
        // console.log(snapVals);
        var categoryName = snapVals.Category;
        // console.log(categoryName);
        var snapUserUID = snapVals.UserUID;
        // console.log(snapUserUID);
        var favoritePath = '/Ads/' + categoryName + '/' + keyName + '/';
        // if (categoryName !== selectCategoryRefVal) {
        //     // swal({
        //     //     type: 'error',
        //     //     title: 'Oops...',
        //     //     text: `Sorry We Have No Data About ${selectCategoryRefVal}`,
        //     // })
        //     console.log('not matched')
        // }
        // else {
        // var keyNameNum = keyName;

        matchedFlag = true;
        var cardDivs = document.createElement('div');
        cardDivs.setAttribute('id', 'cardDiv');
        cardDivs.setAttribute('class', 'card');
        cardDivs.setAttribute('class', 'col-md-3');
        var imgBoxs = document.createElement('img');
        imgBoxs.setAttribute('id', 'imgBox');
        imgBoxs.setAttribute('class', 'card-img-top')
        imgBoxs.src = snapVals.ImageURL;
        var titleDivs = document.createElement('div');
        titleDivs.setAttribute('id', favoritePath);
        titleDivs.setAttribute('class', 'card-img-top titleDiv');
        var headTitle = document.createElement('h4');
        headTitle.setAttribute('id', 'head5');
        headTitle.innerHTML = snapVals.Title;
        var paraModels = document.createElement('p')
        paraModels.setAttribute('id', 'paraModel')
        // var prizeSpan = document.createElement('span');
        // prizeSpan.innerHTML = snapVals.Prize;
        paraModels.innerHTML = snapVals.Model;
        var spanText = document.createElement('span');
        // spanText.setAttribute('id', 'spanTexts');
        var createText = document.createTextNode('Rs:');
        spanText.appendChild(createText);
        var prizeSpan = document.createElement('span');
        prizeSpan.innerHTML = snapVals.Prize;
        var lineBreak = document.createElement('br');
        var iconSpan = document.createElement('span');
        iconSpan.setAttribute('class', 'spanClass');
        iconSpan.style.fontSize = '50px';
        iconSpan.setAttribute('class', 'glyphicon glyphicon-heart-empty');
        var moreBtn = document.createElement('button');
        moreBtn.setAttribute('class', 'btn btn-md btn-success butn');
        var moreBtnText = document.createTextNode('Details')
        moreBtn.appendChild(moreBtnText);

        iconSpan.onclick = function (ev) {
            // if (iconSpan.style.color !== "red") {
            iconSpan.style.color = "red"
            console.log(ev, 'favoritePath');
            console.log(ev.path[1].id, 'favoritePath');

            var currentuseruid = localStorage.getItem('currentUID');
            if (currentuseruid === null) {
                swal({
                    type: 'error',
                    title: 'Oops...',
                    text: 'First You Log In Our Website..'
                },
                    function () {
                        window.location.href = '../pages/logIn.html';
                    })
            }
            else {
                var getPath = ev.path[1].id;
                console.log(getPath);
                db.ref(getPath).on('value', (favSnapshot) => {
                    var favoriteObj = favSnapshot.val();
                    console.log(favoriteObj);
                    db.ref('/Favorite/' + currentuseruid + '/').push(favoriteObj);
                })
            }
            // }
            // else {
            //     console.log(ev, 'favoritePath');
            //     console.log(ev.path[1].id, 'favoritePath');
            //     var currentuseruid = localStorage.getItem('currentUID');
            //     if (currentuseruid === null) {
            //         swal({
            //             type: 'error',
            //             title: 'Oops...',
            //             text: 'First You Log In Our Website..'
            //         },
            //             function () {
            //                 window.location.href = '../pages/logIn.html';
            //             })
            //     }
            //     else {
            //         var getPath = ev.path[1].id;
            //         console.log(getPath);
            //         // db.ref('/Favorite/' + currentuseruid + '/').on('child_added', (favSnapshot) => {
            //         //     var favoriteObj = favSnapshot.val();
            //         //     console.log(favoriteObj);
            //         // })
            //         db.ref('/Favorite/' + currentuseruid + '/').on('child_added', (favObjGet) => {
            //             console.log(favObjGet);
            //         });

            //     }
            // }
        }
        // if (favFlag === true) {
        //     iconSpan.onclick = function (ev) {
        //         favFlag = true;
        //         // iconSpan.setAttribute('class', 'glyphicon glyphicon-heart-red');            
        //         iconSpan.style.color = "darkcyan"
        //         console.log(ev, 'favoritePath');
        //         console.log(ev.path[1].id, 'favoritePath');

        //         var currentuseruid = localStorage.getItem('currentUID');
        //         if (currentuseruid === null) {
        //             swal({
        //                 type: 'error',
        //                 title: 'Oops...',
        //                 text: 'First You Log In Our Website..'
        //             },
        //                 function () {
        //                     window.location.href = '../pages/logIn.html';
        //                 })
        //         }
        //         else {
        //             var getPath = ev.path[1].id;
        //             console.log(getPath);
        //             db.ref(getPath).on('value', (favSnapshot) => {
        //                 console.log(favSnapshot.val());
        //             })
        //         }
        //     }
        // }
        // }
        // else{

        // }
        moreBtn.onclick = function (ev) {
            var getPath = ev.path[1].id;
            localStorage.setItem('Detail Path', getPath);
            window.location = '../pages/detail.html';
        }

        cardDivs.appendChild(imgBoxs);
        cardDivs.appendChild(titleDivs);
        titleDivs.appendChild(headTitle);
        titleDivs.appendChild(paraModels);
        titleDivs.appendChild(createText);
        titleDivs.appendChild(prizeSpan);
        titleDivs.appendChild(lineBreak);
        titleDivs.appendChild(iconSpan);
        titleDivs.appendChild(moreBtn);
        cardDivs.appendChild(titleDivs);
        searchFetchiDiv.appendChild(cardDivs);
    })
}

// Search Category Vice Work End Here

// search anyThing work start from here
var searchAnythings = document.getElementById('index-page-search');
function searchAnything() {
    var searchAnythingVal = searchAnythings.value;
    console.log(searchAnythingVal)
    var searchAnythingStore = localStorage.setItem('searchAnythingStore', searchAnythingVal)
    window.location = "../pages/search-anything.html";
}

function fetchSearchData() {
    var searchVal = localStorage.getItem('searchAnythingStore');
    console.log(searchVal);
    db.ref('/Ads/').on('child_added', (searchSnap) => {
        var snapval = searchSnap.val();
        var snapObj = Object.values(snapval)
        // console.log(snapObj);
        // var snapKey = searchSnap.key;
        // console.log(snapKey);
        for (i = 0; i < snapObj.length; i++) {
            var titleVal = snapObj[i].Title;
            var categoryVal = snapObj[i].Category;
            var modelVal = snapObj[i].Model;
            var descriptionVal = snapObj[i].Description;
            console.log(titleVal);
            console.log(categoryVal);
            console.log(modelVal);
            console.log(descriptionVal);

            if (searchVal.match(titleVal) || searchVal.match(categoryVal) ||
                searchVal.match(modelVal) || searchVal.match(descriptionVal)) {
                console.log('done')
            }else if(i.length === snapObj.length){
                i = 0;
                i++;
            }
        }
    })
}
// search anyThing work end here


// favorite Data Work Start From Here
function fetchFavorite() {
    var currentuseruid = localStorage.getItem('currentUID');
    console.log(currentuseruid);
    swal({
        title: "Loading....!",
        text: "Please wait a moment, data searching....",
        timer: 4000,
        showConfirmButton: false
    });

    db.ref('/Favorite/' + currentuseruid + '/').on('child_added', (favSnap) => {
        var snap = favSnap;
        var keyName = snap.key;
        console.log(keyName);
        console.log(snap);
        var snapVals = favSnap.val();
        console.log(snapVals);
        // var categoryName = snapVals.Category;
        // console.log(categoryName);
        // var snapUserUID = snapVals.UserUID;
        // console.log(snapUserUID);
        var favoritePath = '/Favorite/' + currentuseruid + '/' + keyName + '/';

        var cardDivs = document.createElement('div');
        cardDivs.setAttribute('id', 'cardDiv');
        cardDivs.setAttribute('class', 'card');
        cardDivs.setAttribute('class', 'col-md-3');
        var imgBoxs = document.createElement('img');
        imgBoxs.setAttribute('id', 'imgBox');
        imgBoxs.setAttribute('class', 'card-img-top')
        imgBoxs.src = snapVals.ImageURL;
        var titleDivs = document.createElement('div');
        titleDivs.setAttribute('id', favoritePath);
        titleDivs.setAttribute('class', 'card-img-top titleDiv');
        var headTitle = document.createElement('h4');
        headTitle.setAttribute('id', 'head5');
        headTitle.innerHTML = snapVals.Title;
        var paraModels = document.createElement('p')
        paraModels.setAttribute('id', 'paraModel')
        paraModels.innerHTML = snapVals.Model;
        var spanText = document.createElement('span');
        var createText = document.createTextNode('Rs:');
        spanText.appendChild(createText);
        var prizeSpan = document.createElement('span');
        prizeSpan.innerHTML = snapVals.Prize;
        var lineBreak = document.createElement('br');
        var iconSpan = document.createElement('span');
        iconSpan.setAttribute('class', 'spanClass');
        iconSpan.style.fontSize = '50px';
        iconSpan.style.color = 'red';
        iconSpan.setAttribute('class', 'glyphicon glyphicon-heart-empty');
        var moreBtn = document.createElement('button');
        moreBtn.setAttribute('class', 'btn btn-md btn-success butn');
        var moreBtnText = document.createTextNode('Details')
        moreBtn.appendChild(moreBtnText);

        moreBtn.onclick = function (ev) {
            var getPath = ev.path[1].id;
            localStorage.setItem('Detail Path', getPath);
            window.location = '../pages/detail.html';
        }

        cardDivs.appendChild(imgBoxs);
        cardDivs.appendChild(titleDivs);
        titleDivs.appendChild(headTitle);
        titleDivs.appendChild(paraModels);
        titleDivs.appendChild(createText);
        titleDivs.appendChild(prizeSpan);
        titleDivs.appendChild(lineBreak);
        titleDivs.appendChild(iconSpan);
        titleDivs.appendChild(moreBtn);
        cardDivs.appendChild(titleDivs);
        favFetchiDiv.appendChild(cardDivs);
    })
}

// favorite Data Work End Here




// {
//     name: 'Sell Honda 2007 No Engine Work'
//   }
//   var adsFetched = []; //all ads available
//   var searchKeyword = 'honda 2007';
//   var searchFound = []; //empty array
//   for (var i = 0; i < adsFetched.length; i++) {
//     if (adsFetched[i].name.toLowerCase().search(searchKeyword.toLowerCase()) !== -1) {
//       searchFound.push(adsFetched[i])
//     }
//   }
//   if (searchFound.length > 0) {
//     display()
//   }
//   else{
//     alert('no search found');
//   }